# CRUD API with Node.js, Express, and MongoDB (Mongoose)

This is a simple CRUD (Create, Read, Update, Delete) REST API built using **Node.js**, **Express**, and **MongoDB** with **Mongoose** as the ODM.

---

## 🚀 Features

- Add new items
- Get all items
- Update item by ID
- Delete item by ID
- JSON-based REST API
- MongoDB (local or Atlas)
- Built with Mongoose

---

## 📦 Technologies Used

- Node.js
- Express.js
- MongoDB
- Mongoose
- Postman (for API testing)

---

## 🔧 Setup Instructions

### 1. Clone the Repository

```bash
git clone <your-repo-url>
cd crud-mongoose-app
